powershell -Command "Get-AppxPackage -AllUsers Microsoft.549981C3F5F10 | Remove-AppxPackage" >nul 2>&1
set "targetFolder=%ProgramFiles%\WindowsApps"
set "searchTerm=Microsoft.549981C3F5F10"

for /d %%i in ("%targetFolder%\*%searchTerm%*") do (
    rd /s /q "%%i" >nul 2>nul
)