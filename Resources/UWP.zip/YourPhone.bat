Powershell -Command "Get-AppxPackage -AllUsers "*YourPhone*" | Remove-AppxPackage" >nul 2>&1
set "targetFolder=%ProgramFiles%\WindowsApps"
set "searchTerm=Microsoft.YourPhone" 

for /d %%i in ("%targetFolder%\*%searchTerm%*") do (
    rd /s /q "%%i" >nul 2>nul
)

set "targetFolder=%ProgramFiles%\WindowsApps\DeletedAllUserPackages"
set "searchTerm=Microsoft.YourPhone" 

for /d %%i in ("%targetFolder%\*%searchTerm%*") do (
    rd /s /q "%%i" >nul 2>nul
) 