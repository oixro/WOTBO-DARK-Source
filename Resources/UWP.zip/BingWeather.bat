powershell -Command "Get-AppxPackage -AllUsers *Microsoft.BingWeather* | Remove-AppxPackage" >nul 2>&1
set "targetFolder=%ProgramFiles%\WindowsApps"
set "searchTerm=Microsoft.BingWeather"

for /d %%i in ("%targetFolder%\*%searchTerm%*") do (
    rd /s /q "%%i" >nul 2>nul
)