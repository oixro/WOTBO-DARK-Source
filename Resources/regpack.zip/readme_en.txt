
|regpack-1.55

Pack with .reg files for essential optimization of Windows 10 and 11 Registry
You can use «Restore» folder to restore applied .reg files
Files ending in X require highest privileges

Developed by TECHNOSHAHTA
https://discord.gg/mB6DprqmR9
https://t.me/TECHNOSHAHTA
https://github.com/donkrage/regpack


Content information:
|accessibility.reg - disable settings for people with disabilities
|appcompatibility.reg - disable Application Compatibility components
|attachmentmanager.reg - disable Security Warning when opening files from Internet
|backgroundapps.reg - disable Background apps
|cloudcontent.reg - disable automatic installing promotional UWP apps
|driversearching.reg - disable automatic drivers installing
|edgeupdate.reg - disable background services of Microsoft Edge autoupdate
|filesystem.reg - File System optimization
|gamebar.reg - disable Game Bar
|inspectre.reg - disable Spectre and Meltdown protections
|largesystemcache.reg - enable large system cache
|latestclr.reg - use only latest CLR for .NET components
|maintenance.reg - disable Maintenance
|oldphotoviewer.reg - get back old Windows Photo Viewer
|priority.reg - higher priority for Games
|responsiveness.reg - reduce percent of resources reserved for low-priority tasks
|search.reg - disable web results in Windows Search
|systemrestore.reg - disable System Restore and Shadow Copies service
|uac.reg - disable User Account Control
|win10defenderX.reg - fully disable Windows Defender, including its services and exploits
|win11defenderX.reg - fully disable Windows Defender, including its services and exploits
|win11defsubsvcX.bat - defines Defender sub-service with unique ID and disables it. Apply to fully disable Windows Defender
|win11widgets.reg - disable Widgets and Copilot

Explorer
|3dedit.reg - remove item «Edit with Paint 3D» from context menu
|explorer.reg - basic Windows Explorer setup
|foldernetworkX.reg - remove folder «Network» from Navigation pane (Win 11 includes this in File Explorer options)
|menushowdelay.reg - disable menu show delay
|win10folder3d.reg - remove «3D Objects» folder in Windows Explorer
|win10networkwizard.reg - disable network setup wizard on new networks
|win10shareitem.reg - remove item «Share» from context menu
|win10showsecondsinsystemclock.reg - show seconds in system clock												
|win11contextmenu.reg - classic context menu
|win11shareitem.reg - remove item «Share» from context menu
